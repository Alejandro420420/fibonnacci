package es.iessoterohernandez.daw.endes.FibonnaciProject;

/**
 * Hello world!
 *
 */
public class App 
{
   public int fibonnaci;
   
	    public void sistemaFibonnaci(){
	        int n = 10;
	        System.out.println("Secuencia de fibonacci hasta  " + n + "veces:");

	        int num1 = 0, num2 = 1;

	        System.out.print(num1 + ", " + num2);

	        for (int cont = 2; cont < n; cont++) {
	            int fibonnaci = num1 + num2;
	            System.out.print(", " + fibonnaci);
	            num1 = num2;
	            num2 = fibonnaci;
	        }
	    }
	}


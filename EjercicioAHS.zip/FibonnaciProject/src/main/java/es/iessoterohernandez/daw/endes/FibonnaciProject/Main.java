package es.iessoterohernandez.daw.endes.FibonnaciProject;

/**
 * Hello world!
 *
 */
public class Main 
{
    public static void main( String[] args )
    {
        App p = new App();
        p.sistemaFibonnaci();
    }
}

package es.iessoterohernandez.daw.endes.HelloWorldPDF;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.IOException;

public class App {
    public static final String DEST = "C:\\Users\\usuario24\\Documents\\maven\\HolaPedro.pdf"; 

    public static void main(String[] args) {
        try {
            // Crear un nuevo documento PDF
            Document document = new Document();
            
            // Crear un escritor PDF y vincularlo al archivo de destino
            PdfWriter.getInstance(document, new FileOutputStream(DEST));
            
            // Abrir el documento para agregar contenido
            document.open();
            
            // Crear un párrafo con el texto "Hola Mundo"
            String text = "¡Hola Mundo! Este es un PDF generado con iText en Java.";
            document.add(new Paragraph(text));
            
            // Cerrar el documento
            document.close();
            
            System.out.println("¡PDF creado exitosamente!");
        } catch (IOException e) {
            System.err.println("Error al crear el PDF: " + e.getMessage());
            e.printStackTrace();
        } catch (com.itextpdf.text.DocumentException e) {
            System.err.println("Error con el documento: " + e.getMessage());
            e.printStackTrace();
        }
    }
}